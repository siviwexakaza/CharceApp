﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CharceApp.Models
{
    public enum FileType_Business
    {
        Avatar = 1, Photo
    }
}