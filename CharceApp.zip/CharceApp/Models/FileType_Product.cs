﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CharceApp.Models
{
    public enum FileType_Product
    {
        Avatar = 1, Photo
    }
}