﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CharceApp.Models
{
    public class Follow
    {
        public int ID { get; set; }
        public int PersonalAccID { get; set; }
        public int BusinessID { get; set; }
    }
}